'''Config variables for Address Book database'''


DB = None
C = None