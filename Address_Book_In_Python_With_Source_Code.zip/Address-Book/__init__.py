import config
import db
import AddressBook
import sys
sys.path.insert(0, 'GUI')
from GUI import *